/*    */ package btree;
/*    */ 
/*    */ import global.PageId;
/*    */ 
/*    */ public class IndexData extends DataClass
/*    */ {
/*    */   private PageId pageId;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 11 */     return new Integer(this.pageId.pid).toString();
/*    */   }
/*    */ 
/*    */   IndexData(PageId paramPageId)
/*    */   {
/* 17 */     this.pageId = new PageId(paramPageId.pid);
/*    */   }
/*    */ 
/*    */   IndexData(int paramInt)
/*    */   {
/* 22 */     this.pageId = new PageId(paramInt);
/*    */   }
/*    */ 
/*    */   protected PageId getData()
/*    */   {
/* 28 */     return new PageId(this.pageId.pid);
/*    */   }
/*    */ 
/*    */   protected void setData(PageId paramPageId) {
/* 32 */     this.pageId = new PageId(paramPageId.pid);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.IndexData
 * JD-Core Version:    0.6.0
 */