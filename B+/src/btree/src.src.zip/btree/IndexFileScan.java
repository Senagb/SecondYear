package btree;

public abstract class IndexFileScan
{
  public abstract KeyDataEntry get_next();

  public abstract void delete_current();

  public abstract int keysize();
}

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.IndexFileScan
 * JD-Core Version:    0.6.0
 */