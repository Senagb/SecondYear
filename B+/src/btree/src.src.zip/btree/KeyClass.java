package btree;

public abstract class KeyClass
{
}

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.KeyClass
 * JD-Core Version:    0.6.0
 */