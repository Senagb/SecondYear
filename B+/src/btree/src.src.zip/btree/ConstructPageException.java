/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class ConstructPageException extends ChainException
/*   */ {
/*   */   public ConstructPageException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public ConstructPageException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public ConstructPageException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.ConstructPageException
 * JD-Core Version:    0.6.0
 */