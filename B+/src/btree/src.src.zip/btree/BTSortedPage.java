/*     */ package btree;
/*     */ 
/*     */ import bufmgr.BufMgr;
/*     */ import diskmgr.Page;
/*     */ import global.PageId;
/*     */ import global.RID;
/*     */ import global.SystemDefs;
/*     */ import heap.HFPage;
/*     */ import heap.InvalidSlotNumberException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class BTSortedPage extends HFPage
/*     */ {
/*     */   int keyType;
/*     */ 
/*     */   public BTSortedPage(PageId paramPageId, int paramInt)
/*     */     throws ConstructPageException
/*     */   {
/*     */     try
/*     */     {
/*  41 */       SystemDefs.JavabaseBM.pinPage(paramPageId, this, false);
/*  42 */       this.keyType = paramInt;
/*     */ 
/*  39 */       return;
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */ 
/*  45 */     throw new ConstructPageException(localException, "construct sorted page failed");
/*     */   }
/*     */ 
/*     */   public BTSortedPage(Page paramPage, int paramInt)
/*     */   {
/*  57 */     super(paramPage);
/*  58 */     this.keyType = paramInt;
/*     */   }
/*     */ 
/*     */   public BTSortedPage(int paramInt)
/*     */     throws ConstructPageException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       Page localPage = new Page();
/*  73 */       PageId localPageId = SystemDefs.JavabaseBM.newPage(localPage, 1);
/*  74 */       if (localPageId == null)
/*  75 */         throw new ConstructPageException(null, "construct new page failed");
/*  76 */       init(localPageId, localPage);
/*  77 */       this.keyType = paramInt;
/*     */ 
/*  71 */       return;
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  80 */       localException.printStackTrace();
/*  81 */     }throw new ConstructPageException(localException, "construct sorted page failed");
/*     */   }
/*     */ 
/*     */   public RID insertRecord(KeyDataEntry paramKeyDataEntry)
/*     */     throws InsertRecException
/*     */   {
/*     */     try
/*     */     {
/* 113 */       byte[] arrayOfByte = BT.getBytesFromEntry(paramKeyDataEntry);
/* 114 */       RID localRID = super.insertRecord(arrayOfByte);
/* 115 */       if (localRID == null) return null;
/*     */       short s;
/* 117 */       if ((paramKeyDataEntry.data instanceof LeafData))
/* 118 */         s = 12;
/*     */       else {
/* 120 */         s = 11;
/*     */       }
/*     */ 
/* 124 */       for (int i = getSlotCnt() - 1; i > 0; i--)
/*     */       {
/* 129 */         KeyClass localKeyClass1 = BT.getEntryFromBytes(getpage(), getSlotOffset(i), 
/* 130 */           getSlotLength(i), this.keyType, s).key;
/*     */ 
/* 132 */         KeyClass localKeyClass2 = BT.getEntryFromBytes(getpage(), getSlotOffset(i - 1), 
/* 133 */           getSlotLength(i - 1), this.keyType, s).key;
/*     */ 
/* 135 */         if (BT.keyCompare(localKeyClass1, localKeyClass2) >= 0)
/*     */         {
/*     */           break;
/*     */         }
/* 139 */         int j = getSlotLength(i);
/* 140 */         int k = getSlotOffset(i);
/* 141 */         setSlot(i, getSlotLength(i - 1), getSlotOffset(i - 1));
/* 142 */         setSlot(i - 1, j, k);
/*     */       }
/*     */ 
/* 155 */       localRID.slotNo = i;
/* 156 */       return localRID;
/*     */     } catch (Exception localException) {
/*     */     }
/* 159 */     throw new InsertRecException(localException, "insert record failed");
/*     */   }
/*     */ 
/*     */   public boolean deleteSortedRecord(RID paramRID)
/*     */     throws DeleteRecException
/*     */   {
/*     */     try
/*     */     {
/* 177 */       deleteRecord(paramRID);
/* 178 */       compact_slot_dir();
/* 179 */       return true;
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 184 */       if ((localException instanceof InvalidSlotNumberException))
/* 185 */         return false;
/*     */     }
/* 187 */     throw new DeleteRecException(localException, "delete record failed");
/*     */   }
/*     */ 
/*     */   protected int numberOfRecords()
/*     */     throws IOException
/*     */   {
/* 198 */     return getSlotCnt();
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.BTSortedPage
 * JD-Core Version:    0.6.0
 */