/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class ConvertException extends ChainException
/*   */ {
/*   */   public ConvertException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public ConvertException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public ConvertException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.ConvertException
 * JD-Core Version:    0.6.0
 */