package btree;

public class NodeType
{
  public static final short INDEX = 11;
  public static final short LEAF = 12;
  public static final short BTHEAD = 13;
}

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.NodeType
 * JD-Core Version:    0.6.0
 */