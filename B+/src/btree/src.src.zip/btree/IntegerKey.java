/*    */ package btree;
/*    */ 
/*    */ public class IntegerKey extends KeyClass
/*    */ {
/*    */   private Integer key;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 11 */     return this.key.toString();
/*    */   }
/*    */ 
/*    */   public IntegerKey(Integer paramInteger)
/*    */   {
/* 19 */     this.key = new Integer(paramInteger.intValue());
/*    */   }
/*    */ 
/*    */   public IntegerKey(int paramInt)
/*    */   {
/* 27 */     this.key = new Integer(paramInt);
/*    */   }
/*    */ 
/*    */   public Integer getKey()
/*    */   {
/* 37 */     return new Integer(this.key.intValue());
/*    */   }
/*    */ 
/*    */   public void setKey(Integer paramInteger)
/*    */   {
/* 44 */     this.key = new Integer(paramInteger.intValue());
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.IntegerKey
 * JD-Core Version:    0.6.0
 */