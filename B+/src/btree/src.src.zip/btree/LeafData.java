/*    */ package btree;
/*    */ 
/*    */ import global.PageId;
/*    */ import global.RID;
/*    */ 
/*    */ public class LeafData extends DataClass
/*    */ {
/*    */   private RID myRid;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 12 */     String str = "[ " + new Integer(this.myRid.pageNo.pid).toString() + " " + 
/* 13 */       new Integer(this.myRid.slotNo).toString() + " ]";
/* 14 */     return str;
/*    */   }
/*    */ 
/*    */   LeafData(RID paramRID)
/*    */   {
/* 20 */     this.myRid = new RID(paramRID.pageNo, paramRID.slotNo);
/*    */   }
/*    */ 
/*    */   public RID getData()
/*    */   {
/* 25 */     return new RID(this.myRid.pageNo, this.myRid.slotNo);
/*    */   }
/*    */ 
/*    */   public void setData(RID paramRID) {
/* 29 */     this.myRid = new RID(paramRID.pageNo, paramRID.slotNo);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.LeafData
 * JD-Core Version:    0.6.0
 */