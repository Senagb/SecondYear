/*    */ package btree;
/*    */ 
/*    */ public class StringKey extends KeyClass
/*    */ {
/*    */   private String key;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 11 */     return this.key;
/*    */   }
/*    */ 
/*    */   public StringKey(String paramString)
/*    */   {
/* 17 */     this.key = new String(paramString);
/*    */   }
/*    */ 
/*    */   public String getKey()
/*    */   {
/* 22 */     return new String(this.key);
/*    */   }
/*    */ 
/*    */   public void setKey(String paramString) {
/* 26 */     this.key = new String(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.StringKey
 * JD-Core Version:    0.6.0
 */