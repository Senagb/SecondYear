/*     */ package btree;
/*     */ 
/*     */ import global.PageId;
/*     */ import global.RID;
/*     */ 
/*     */ public class KeyDataEntry
/*     */ {
/*     */   public KeyClass key;
/*     */   public DataClass data;
/*     */ 
/*     */   public KeyDataEntry(Integer paramInteger, PageId paramPageId)
/*     */   {
/*  22 */     this.key = new IntegerKey(paramInteger);
/*  23 */     this.data = new IndexData(paramPageId);
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(KeyClass paramKeyClass, PageId paramPageId)
/*     */   {
/*  32 */     this.data = new IndexData(paramPageId);
/*  33 */     if ((paramKeyClass instanceof IntegerKey)) {
/*  34 */       this.key = new IntegerKey(((IntegerKey)paramKeyClass).getKey());
/*     */ 
/*  33 */       return;
/*     */     }
/*  35 */     if ((paramKeyClass instanceof StringKey))
/*  36 */       this.key = new StringKey(((StringKey)paramKeyClass).getKey());
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(String paramString, PageId paramPageId)
/*     */   {
/*  43 */     this.key = new StringKey(paramString);
/*  44 */     this.data = new IndexData(paramPageId);
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(Integer paramInteger, RID paramRID)
/*     */   {
/*  50 */     this.key = new IntegerKey(paramInteger);
/*  51 */     this.data = new LeafData(paramRID);
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(KeyClass paramKeyClass, RID paramRID)
/*     */   {
/*  57 */     this.data = new LeafData(paramRID);
/*  58 */     if ((paramKeyClass instanceof IntegerKey)) {
/*  59 */       this.key = new IntegerKey(((IntegerKey)paramKeyClass).getKey());
/*     */ 
/*  58 */       return;
/*     */     }
/*  60 */     if ((paramKeyClass instanceof StringKey))
/*  61 */       this.key = new StringKey(((StringKey)paramKeyClass).getKey());
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(String paramString, RID paramRID)
/*     */   {
/*  68 */     this.key = new StringKey(paramString);
/*  69 */     this.data = new LeafData(paramRID);
/*     */   }
/*     */ 
/*     */   public KeyDataEntry(KeyClass paramKeyClass, DataClass paramDataClass)
/*     */   {
/*  75 */     if ((paramKeyClass instanceof IntegerKey))
/*  76 */       this.key = new IntegerKey(((IntegerKey)paramKeyClass).getKey());
/*  77 */     else if ((paramKeyClass instanceof StringKey)) {
/*  78 */       this.key = new StringKey(((StringKey)paramKeyClass).getKey());
/*     */     }
/*  80 */     if ((paramDataClass instanceof IndexData)) {
/*  81 */       this.data = new IndexData(((IndexData)paramDataClass).getData());
/*     */ 
/*  80 */       return;
/*     */     }
/*  82 */     if ((paramDataClass instanceof LeafData))
/*  83 */       this.data = new LeafData(((LeafData)paramDataClass).getData());
/*     */   }
/*     */ 
/*     */   public boolean equals(KeyDataEntry paramKeyDataEntry)
/*     */   {
/*     */     boolean bool1;
/*  93 */     if ((this.key instanceof IntegerKey))
/*  94 */       bool1 = ((IntegerKey)this.key).getKey()
/*  95 */         .equals(((IntegerKey)paramKeyDataEntry.key).getKey());
/*     */     else
/*  97 */       bool1 = ((StringKey)this.key).getKey()
/*  98 */         .equals(((StringKey)paramKeyDataEntry.key).getKey());
/*     */     boolean bool2;
/* 100 */     if ((this.data instanceof IndexData))
/* 101 */       bool2 = ((IndexData)this.data).getData().pid == 
/* 102 */         ((IndexData)paramKeyDataEntry.data).getData().pid;
/*     */     else {
/* 104 */       bool2 = ((LeafData)this.data).getData()
/* 105 */         .equals(((LeafData)paramKeyDataEntry.data).getData());
/*     */     }
/*     */ 
/* 108 */     return (bool1) && (bool2);
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.KeyDataEntry
 * JD-Core Version:    0.6.0
 */