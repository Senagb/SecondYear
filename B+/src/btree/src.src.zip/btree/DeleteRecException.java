/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class DeleteRecException extends ChainException
/*   */ {
/*   */   public DeleteRecException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public DeleteRecException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public DeleteRecException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.DeleteRecException
 * JD-Core Version:    0.6.0
 */