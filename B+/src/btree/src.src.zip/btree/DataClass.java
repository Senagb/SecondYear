package btree;

public abstract class DataClass
{
}

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.DataClass
 * JD-Core Version:    0.6.0
 */