/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class KeyNotMatchException extends ChainException
/*   */ {
/*   */   public KeyNotMatchException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public KeyNotMatchException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public KeyNotMatchException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.KeyNotMatchException
 * JD-Core Version:    0.6.0
 */