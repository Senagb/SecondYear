/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class NodeNotMatchException extends ChainException
/*   */ {
/*   */   public NodeNotMatchException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public NodeNotMatchException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public NodeNotMatchException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.NodeNotMatchException
 * JD-Core Version:    0.6.0
 */