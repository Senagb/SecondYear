package btree;

import global.RID;

public abstract class IndexFile
{
  public abstract void insert(KeyClass paramKeyClass, RID paramRID);

  public abstract boolean Delete(KeyClass paramKeyClass, RID paramRID);
}

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.IndexFile
 * JD-Core Version:    0.6.0
 */