/*     */ package btree;
/*     */ 
/*     */ import global.Convert;
/*     */ import global.GlobalConst;
/*     */ import global.PageId;
/*     */ import global.RID;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class BT
/*     */   implements GlobalConst
/*     */ {
/*     */   public static final int keyCompare(KeyClass paramKeyClass1, KeyClass paramKeyClass2)
/*     */     throws KeyNotMatchException
/*     */   {
/*  53 */     if (((paramKeyClass1 instanceof IntegerKey)) && ((paramKeyClass2 instanceof IntegerKey)))
/*     */     {
/*  55 */       return ((IntegerKey)paramKeyClass1).getKey().intValue() - 
/*  56 */         ((IntegerKey)paramKeyClass2).getKey().intValue();
/*     */     }
/*  58 */     if (((paramKeyClass1 instanceof StringKey)) && ((paramKeyClass2 instanceof StringKey))) {
/*  59 */       return ((StringKey)paramKeyClass1).getKey().compareTo(((StringKey)paramKeyClass2).getKey());
/*     */     }
/*     */ 
/*  62 */     throw new KeyNotMatchException(null, "key types do not match");
/*     */   }
/*     */ 
/*     */   public static final int getKeyLength(KeyClass paramKeyClass)
/*     */     throws KeyNotMatchException, IOException
/*     */   {
/*  77 */     if ((paramKeyClass instanceof StringKey))
/*     */     {
/*  79 */       ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  80 */       DataOutputStream localDataOutputStream = new DataOutputStream(localByteArrayOutputStream);
/*  81 */       localDataOutputStream.writeUTF(((StringKey)paramKeyClass).getKey());
/*  82 */       return localDataOutputStream.size();
/*     */     }
/*  84 */     if ((paramKeyClass instanceof IntegerKey))
/*  85 */       return 4;
/*  86 */     throw new KeyNotMatchException(null, "key types do not match");
/*     */   }
/*     */ 
/*     */   public static final int getDataLength(short paramShort)
/*     */     throws NodeNotMatchException
/*     */   {
/* 100 */     if (paramShort == 12)
/* 101 */       return 8;
/* 102 */     if (paramShort == 11)
/* 103 */       return 4;
/* 104 */     throw new NodeNotMatchException(null, "key types do not match");
/*     */   }
/*     */ 
/*     */   public static final int getKeyDataLength(KeyClass paramKeyClass, short paramShort)
/*     */     throws KeyNotMatchException, NodeNotMatchException, IOException
/*     */   {
/* 121 */     return getKeyLength(paramKeyClass) + getDataLength(paramShort);
/*     */   }
/*     */ 
/*     */   public static final KeyDataEntry getEntryFromBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, short paramShort)
/*     */     throws KeyNotMatchException, NodeNotMatchException, ConvertException
/*     */   {
/*     */     try
/*     */     {
/*     */       int i;
/*     */       Object localObject2;
/* 153 */       if (paramShort == 11) {
/* 154 */         i = 4;
/* 155 */         localObject2 = new IndexData(Convert.getIntValue(paramInt1 + paramInt2 - 4, paramArrayOfByte));
/*     */       }
/* 157 */       else if (paramShort == 12) {
/* 158 */         i = 8;
/* 159 */         RID localRID = new RID();
/* 160 */         localRID.slotNo = Convert.getIntValue(paramInt1 + paramInt2 - 8, paramArrayOfByte);
/* 161 */         localRID.pageNo = new PageId();
/* 162 */         localRID.pageNo.pid = Convert.getIntValue(paramInt1 + paramInt2 - 4, paramArrayOfByte);
/* 163 */         localObject2 = new LeafData(localRID);
/*     */       } else {
/* 165 */         throw new NodeNotMatchException(null, "node types do not match");
/*     */       }
/*     */       Object localObject1;
/* 167 */       if (paramInt3 == 1) {
/* 168 */         localObject1 = new IntegerKey(new Integer(
/* 169 */           Convert.getIntValue(paramInt1, paramArrayOfByte)));
/*     */       }
/* 171 */       else if (paramInt3 == 0)
/*     */       {
/* 173 */         localObject1 = new StringKey(Convert.getStrValue(paramInt1, paramArrayOfByte, paramInt2 - i));
/*     */       }
/*     */       else {
/* 176 */         throw new KeyNotMatchException(null, "key types do not match");
/*     */       }
/* 178 */       return new KeyDataEntry((KeyClass)localObject1, (DataClass)localObject2);
/*     */     }
/*     */     catch (IOException localIOException) {
/*     */     }
/* 182 */     throw new ConvertException(localIOException, "convert faile");
/*     */   }
/*     */ 
/*     */   public static final byte[] getBytesFromEntry(KeyDataEntry paramKeyDataEntry)
/*     */     throws KeyNotMatchException, NodeNotMatchException, ConvertException
/*     */   {
/*     */     try
/*     */     {
/* 202 */       int i = getKeyLength(paramKeyDataEntry.key);
/* 203 */       int j = i;
/* 204 */       if ((paramKeyDataEntry.data instanceof IndexData))
/* 205 */         i += 4;
/* 206 */       else if ((paramKeyDataEntry.data instanceof LeafData)) {
/* 207 */         i += 8;
/*     */       }
/* 209 */       byte[] arrayOfByte = new byte[i];
/*     */ 
/* 211 */       if ((paramKeyDataEntry.key instanceof IntegerKey)) {
/* 212 */         Convert.setIntValue(((IntegerKey)paramKeyDataEntry.key).getKey().intValue(), 
/* 213 */           0, arrayOfByte);
/*     */       }
/* 215 */       else if ((paramKeyDataEntry.key instanceof StringKey))
/* 216 */         Convert.setStrValue(((StringKey)paramKeyDataEntry.key).getKey(), 
/* 217 */           0, arrayOfByte);
/*     */       else {
/* 219 */         throw new KeyNotMatchException(null, "key types do not match");
/*     */       }
/* 221 */       if ((paramKeyDataEntry.data instanceof IndexData)) {
/* 222 */         Convert.setIntValue(((IndexData)paramKeyDataEntry.data).getData().pid, 
/* 223 */           j, arrayOfByte);
/*     */       }
/* 225 */       else if ((paramKeyDataEntry.data instanceof LeafData)) {
/* 226 */         Convert.setIntValue(((LeafData)paramKeyDataEntry.data).getData().slotNo, 
/* 227 */           j, arrayOfByte);
/* 228 */         Convert.setIntValue(((LeafData)paramKeyDataEntry.data).getData().pageNo.pid, 
/* 229 */           j + 4, arrayOfByte);
/*     */       }
/*     */       else {
/* 232 */         throw new NodeNotMatchException(null, "node types do not match");
/* 233 */       }return arrayOfByte;
/*     */     } catch (IOException localIOException) {
/*     */     }
/* 236 */     throw new ConvertException(localIOException, "convert failed");
/*     */   }
/*     */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.BT
 * JD-Core Version:    0.6.0
 */