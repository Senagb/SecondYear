/*   */ package btree;
/*   */ 
/*   */ import chainexception.ChainException;
/*   */ 
/*   */ public class InsertRecException extends ChainException
/*   */ {
/*   */   public InsertRecException()
/*   */   {
/*   */   }
/*   */ 
/*   */   public InsertRecException(String paramString)
/*   */   {
/* 7 */     super(null, paramString); } 
/* 8 */   public InsertRecException(Exception paramException, String paramString) { super(paramException, paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\user\Desktop\b_tree\BTree\assign\src\
 * Qualified Name:     btree.InsertRecException
 * JD-Core Version:    0.6.0
 */